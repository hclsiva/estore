Ext.onReady(function(){
  Ext.application('ApplicationImpl');
});

