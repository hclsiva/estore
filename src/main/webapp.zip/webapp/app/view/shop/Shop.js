Ext.define('estore.view.shop.Shop', {
    extend: 'Ext.panel.Panel',
    xtype: 'shop',
    requires: [
        'Ext.toolbar.TextItem',
        'Ext.view.View',
        'Ext.ux.BoxReorderer',
        'Ext.ux.DataView.Animated'
    ],
    layout:'fit',
	align:'stretch',
	border:0,
	flex:1,
	overflowY:'auto',
    items: [{
                xtype: 'dataview',
                reference: 'dataview',
                plugins: {
                    ptype: 'ux-animated-dataview'
                },

                itemSelector: 'div.dataview-multisort-item',
                tpl: [
                    '<tpl for=".">',
                        '<div class="dataview-multisort-item">',
                            '<img src="resources/images/product_images/{image}" />',
                            '<h3>{name}</h3>',
                        '</div>',
                    '</tpl>'
                ],

                store: {
                    autoLoad: true,
                    sortOnLoad: true,
                    fields: ['name', 'image'],
                    proxy: {
                        type: 'ajax',
                        url : 'app/data/product.json',
                        reader: {
                            type: 'json',
                            rootProperty: ''
                        }
                    }
                }
            }]
});