Ext.define('estore.view.shop.Search', {
    extend: 'Ext.panel.Panel',
    xtype: 'search',
    requires: [],
    layout:'fit',
	align:'stretch',
	border:0,
	flex:1
});