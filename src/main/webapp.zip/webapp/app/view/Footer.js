Ext.define('estore.view.Footer', {
    extend: 'Ext.Container',
    xtype: 'appFooter',
    height: 30,
    frame:false,
    border:false,
    bodyCls: 'x-panel-body-default-framed',
    layout: {
        type: 'hbox',
        align: 'center',
        pack: 'center'
    },         
	items : [{
		xtype: 'label',
		html: '2019 @ Turing'		
	}]

});
