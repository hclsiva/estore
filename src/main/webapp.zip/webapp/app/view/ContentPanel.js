Ext.define('estore.view.ContentPanel', {
    extend: 'Ext.panel.Panel',
    xtype: 'contentPanel',
    id: 'content-panel',
    scrollable: true,
	requires:[		
		'estore.view.shop.Shop'
    ], 
    header: {
        hidden: true
    },
	items:[{
		xtype: 'shop'
	}]
});
