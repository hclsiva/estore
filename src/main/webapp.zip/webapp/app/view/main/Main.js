Ext.define('estore.view.main.Main',
{
	extend: 'Ext.container.Viewport',
    xtype:'app-main',
    id:'app-main',
    renderTo: Ext.getBody(),
    requires:[
        'Ext.tab.Panel',
        'Ext.layout.container.Border',
		'estore.view.Header',
		'estore.view.ContentPanel',
		'estore.view.navigation.Breadcrumb',
		'estore.view.Footer'
    ],    
    layout: 'border',
   
    items: [{
        region: 'north',
        xtype: 'appHeader',
        padding:10
    },{
		region: 'south',
        xtype:'appFooter',
        padding:10
	} ,{
		region: 'west',
        xtype:'panel',
        width:350,        
        padding:5
	} ,{
        region: 'center',
        xtype: 'contentPanel',
        reference: 'contentPanel',
        ariaRole: 'main',
        layout:'fit',        
        padding:5       
    }]
});
	