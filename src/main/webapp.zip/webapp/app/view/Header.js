Ext.define('estore.view.Header', {
    extend: 'Ext.container.Container',
    xtype: 'appHeader',
    title: 'E-Store Application',
    layout:{
		type:'hbox',
		align:'stretch'
    },
    requires:['Ext.form.Label',
              'Ext.form.FieldSet'
    ],
    height:75,
    border:10,
    baseCls:'app-tool-bar',
    items : [{
        xtype:'component',
        autoEl:'div',
        html:'<div><img src="resources/images/tshirtshop.png"/></div>',
        align:'bottom'
    },{xtype:'tbfill'},{xtype:'tbfill'},
    {
      xtype: 'textfield',
      width:700,
      maxHeight:10,
      align:'bottom',
      name: 'query',
      cls:'rounded',
      padding:10,
      triggers:{
        search:{
              cls:'x-form-search-trigger',
              handler: function () {
              }
        }
    },
    },{xtype:'tbfill'},
    /**{
      xtype: 'fieldset',
      title: 'Search',
      items: [
          {
              xtype: 'textfield',
              label: 'Search T-Shirts',
              name: 'query'
          }
      ]
  }*/,{
        xtype:'button',
        width: 'auto',
        maxHeight:30,
        iconCls: 'admin-ico',
        cls:'header-menu-plain-background',
        menu: {
        showSeparator :false,
        plain:true,
        items: [{
            text: 'Change Password'
        },{
            text: 'Logout',            
            }]
        }
  },{
    xtype:'button',
    width: 'auto',
    maxHeight:30,
    iconCls: 'help-ico',
    enabled:true,
    cls:'header-menu-plain-background',
    menu: {
      showSeparator :false,
      plain:true,
      items: [{
        text: 'Info',
      },{
        text: 'Help'
      }]
    }
  }]
});
